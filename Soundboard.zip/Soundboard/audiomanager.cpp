#include "audiomanager.h"
#include <QUrl>
#include <QSoundEffect>
#include <QCoreApplication>
#include <fstream>
#include <sstream>
#include <QtEndian>
#include <iostream>
#include <limits>

// the following struct is adapted from https://stackoverflow.com/questions/17968561/loading-and-saving-wav-file
struct WaveFile
{
public:

    static const quint16 NUM_CHARS = 4;

public:

    WaveFile() : Data(nullptr) {}
    ~WaveFile() { delete Data; }

    char ChunkID[NUM_CHARS];
    quint32 ChunkSize;

    char Format[NUM_CHARS];

    char SubChunkID[NUM_CHARS];
    quint32 SubChunkSize;

    quint16 AudioFormat;
    quint16 NumChannels;
    quint32 SampleRate;
    quint32 ByteRate;
    quint16 BlockAlign;
    quint16 BitsPerSample;

    char SubChunk2ID[NUM_CHARS];
    quint32 SubChunk2Size;

    char* Data;
};

AudioManager::AudioManager()
{
    // sets up Audio Format
    format.setSampleRate(48000);
    format.setChannelCount(2);
    format.setSampleSize(16);
    format.setCodec("audio/pcm");
    format.setByteOrder(QAudioFormat::LittleEndian);
    format.setSampleType(QAudioFormat::UnSignedInt);

    setAudioFormat(format);

    // sets up readTrack
    readTrack = new QFile("readTrack.wav");
    readTrack->remove();

    // sets up output files
    sounds_output = new QFile("sounds_output.raw");
    mic_output = new QFile("mic_output.raw");
    sounds_output->remove();
    mic_output->remove();

    // sets up audioInput
//    audioInput_mic = new QAudioInput(QAudioDeviceInfo::defaultInputDevice(), format);
//    audioInput_mic->setVolume(0.0f);
    recorder = new QAudioRecorder();

    QAudioEncoderSettings settings;
    settings.setCodec("audio/pcm");
    settings.setChannelCount(2);
    settings.setSampleRate(48000);
    int bitRate = 48000 * format.sampleSize();
    settings.setBitRate(bitRate);
    settings.setEncodingMode(QMultimedia::ConstantBitRateEncoding);

    recorder->setAudioInput(recorder->defaultAudioInput());
    recorder->setAudioSettings(settings);
    recorder->setContainerFormat("audio/x-raw");
    QString path(QCoreApplication::applicationDirPath().left(QCoreApplication::applicationDirPath().size() - 5) + mic_output->fileName());
    recorder->setOutputLocation(QUrl::fromLocalFile(path));

    // sets up writeTrack
    writeTrack = new QFile("writeTrack.wav");

    // sets up audioOutput
    audioOutput = new QAudioOutput(QAudioDeviceInfo::defaultOutputDevice(), format);
    connect(audioOutput, SIGNAL(stateChanged(QAudio::State)),
            this, SLOT (audioOutputStateChanged(QAudio::State)));
}

AudioManager::~AudioManager()
{
    audioOutput->stop();

    readTrack->close();
    writeTrack->close();
    readTrack->remove();
    writeTrack->remove();

//    audioInput_mic->stop();
    recorder->stop();

    mic_output->close();
    mic_output->remove();
    sounds_output->close();
    sounds_output->remove();
}

void AudioManager::setAudioFormat(QAudioFormat &format) {
    this->format = format;

    QAudioDeviceInfo info(QAudioDeviceInfo::defaultOutputDevice());

    if (!info.isFormatSupported(format)) {
          format = info.nearestFormat(format);
          qDebug() << "Raw audio format not supported, trying nearest";
      }

    // the following was adapted from qt example audioinput
    switch (format.sampleSize()) {
    case 8:
        switch (format.sampleType()) {
        case QAudioFormat::UnSignedInt:
            maxAmplitude = 255;
            break;
        case QAudioFormat::SignedInt:
            maxAmplitude = 127;
            break;
        default:
            break;
        }
        break;
    case 16:
        switch (format.sampleType()) {
        case QAudioFormat::UnSignedInt:
            maxAmplitude = 65535;
            break;
        case QAudioFormat::SignedInt:
            maxAmplitude = 32767;
            break;
        default:
            break;
        }
        break;

    case 32:
        switch (format.sampleType()) {
        case QAudioFormat::UnSignedInt:
            maxAmplitude = 0xffffffff;
            break;
        case QAudioFormat::SignedInt:
            maxAmplitude = 0x7fffffff;
            break;
        case QAudioFormat::Float:
            maxAmplitude = 0x7fffffff;
        default:
            break;
        }
        break;

    default:
        break;
    }
}

bool AudioManager::isPlaying()
{
    return playing;
}

void AudioManager::setRecordingSoundboard(bool recording)
{
    this->recordingSoundboard = recording;
}

bool AudioManager::isRecordingSoundboard()
{
    return recordingSoundboard;
}

void AudioManager::setRecordingMic(bool recording)
{
    this->recordingMic = recording;

    // mute audioInput if not recording
    if (recording) {
//        audioInput_mic->setVolume(1.0f);
        recorder->setVolume(1.0f);
        if (!mic_output->isOpen()) {
//            mic_output->open(QIODevice::ReadWrite|QFile::Truncate);
        }
    } else {
//        audioInput_mic->setVolume(0.0f);
        recorder->setVolume(0.0f);
    }
}

bool AudioManager::isRecordingMic()
{
    return recordingMic;
}

QFile* AudioManager::getTrack()
{
    return readTrack;
}

// loop track
void AudioManager::loop()
{
    audioOutput->stop();
//    audioInput_mic->stop();
    recorder->stop();

    int mic_output_size = mic_output->size();
    int sounds_output_size = sounds_output->size();

    mic_output->close();

    // initializes default WaveFile information
    WaveFile waveFile;
    waveFile.ChunkID[0] = 'R';
    waveFile.ChunkID[1] = 'I';
    waveFile.ChunkID[2] = 'F';
    waveFile.ChunkID[3] = 'F';
    waveFile.Format[0] = 'W';
    waveFile.Format[1] = 'A';
    waveFile.Format[2] = 'V';
    waveFile.Format[3] = 'E';
    waveFile.SubChunkID[0] = 'f';
    waveFile.SubChunkID[1] = 'm';
    waveFile.SubChunkID[2] = 't';
    waveFile.SubChunkID[3] = ' ';
    waveFile.SubChunkSize = 16;
    waveFile.AudioFormat = 1;
    waveFile.SubChunk2ID[0] = 'd';
    waveFile.SubChunk2ID[1] = 'a';
    waveFile.SubChunk2ID[2] = 't';
    waveFile.SubChunk2ID[3] = 'a';
    waveFile.BitsPerSample = 16;

    std::string filePath;

    // fills arr to current index with readTrack

    QByteArray arr_track("");

    if (readTrack->exists()) {
        readTrack->close();
        // creates wavefile with byte array
        filePath = readTrack->fileName().toStdString().substr(0);

        FILE *file = fopen(filePath.data(), "rb");
        fread(waveFile.ChunkID, 4, 1, file);
        fread(reinterpret_cast<char*>(&waveFile.ChunkSize), 4, 1, file);
        fread(waveFile.Format, 4, 1, file);
        fread(waveFile.SubChunkID, 4, 1, file);
        fread(reinterpret_cast<char*>(&waveFile.SubChunkSize), 4, 1, file);
        fread(reinterpret_cast<char*>(&waveFile.AudioFormat), 2, 1, file);
        fread(reinterpret_cast<char*>(&waveFile.NumChannels), 2, 1, file);
        fread(reinterpret_cast<char*>(&waveFile.SampleRate), 4, 1, file);
        fread(reinterpret_cast<char*>(&waveFile.ByteRate), 4, 1, file);
        fread(reinterpret_cast<char*>(&waveFile.BlockAlign), 2, 1, file);
        fread(reinterpret_cast<char*>(&waveFile.BitsPerSample), 2, 1, file);
        fread(waveFile.SubChunk2ID, 4, 1, file);
        fread(reinterpret_cast<char*>(&waveFile.SubChunk2Size), 4, 1, file);
        QByteArray data("");
        for (quint32 i = 0; i < waveFile.SubChunk2Size; i++) {
            data.push_back((char)fgetc(file));
        }

        fclose(file);

        if (data.size())

        // puts track in at least once
        for (int i = 0; i < data.size(); i++) {
            arr_track.push_back(data.at(i));
        }

        // loops track until current index
        int i_waveFile = 0;
        for (int i = data.size(); (i < mic_output_size || i < sounds_output_size) && data.size() > 0; i++) {
            arr_track.push_back(data.at(i_waveFile));
            i_waveFile++;
            if (i_waveFile >= data.size()) {
                i_waveFile = 0;
            }
        }
    }

    mic_output->open(QIODevice::ReadOnly);
    sounds_output->open(QIODevice::ReadOnly);

    QByteArray arr_mic("");
    QByteArray arr_sounds("");

    if (mic_output->exists()) {
        arr_mic = mic_output->readAll();
    }

    if (sounds_output->exists()) {
        sounds_output->open(QIODevice::ReadOnly);
        arr_sounds = sounds_output->readAll();
    }

    // writes everything to writeTrack

    writeTrack->open(QIODevice::WriteOnly);

    // change wavefile information to format
    waveFile.NumChannels = format.channelCount();
    waveFile.SampleRate = format.sampleRate();
    waveFile.ByteRate = waveFile.SampleRate * waveFile.NumChannels * waveFile.BitsPerSample/8;
    waveFile.BlockAlign = waveFile.NumChannels * waveFile.BitsPerSample/8;
    waveFile.SubChunk2Size = qMax(qMax(arr_track.size(), arr_mic.size()), arr_sounds.size());
    waveFile.ChunkSize = 36 + waveFile.SubChunk2Size;

    filePath = writeTrack->fileName().toStdString().substr(0);

    FILE *filewrite = fopen(filePath.data(), "wb");
    fwrite(waveFile.ChunkID, 4, 1, filewrite);
    fwrite(reinterpret_cast<char*>(&waveFile.ChunkSize), 4, 1, filewrite);
    fwrite(waveFile.Format, 4, 1, filewrite);
    fwrite(waveFile.SubChunkID, 4, 1, filewrite);
    fwrite(reinterpret_cast<char*>(&waveFile.SubChunkSize), 4, 1, filewrite);
    fwrite(reinterpret_cast<char*>(&waveFile.AudioFormat), 2, 1, filewrite);
    fwrite(reinterpret_cast<char*>(&waveFile.NumChannels), 2, 1, filewrite);
    fwrite(reinterpret_cast<char*>(&waveFile.SampleRate), 4, 1, filewrite);
    fwrite(reinterpret_cast<char*>(&waveFile.ByteRate), 4, 1, filewrite);
    fwrite(reinterpret_cast<char*>(&waveFile.BlockAlign), 2, 1, filewrite);
    fwrite(reinterpret_cast<char*>(&waveFile.BitsPerSample), 2, 1, filewrite);
    fwrite(waveFile.SubChunk2ID, 4, 1, filewrite);
    fwrite(reinterpret_cast<char*>(&waveFile.SubChunk2Size), 4, 1, filewrite);

    int sampleSize = format.sampleSize() / 8;

    // writes data
    for (int i = 0; i < sounds_output_size || i < mic_output_size || i < arr_track.size();  i+= sampleSize) {
        quint32 value = 0;
        int numAdds = 0;
        if (i + sampleSize - 1 < sounds_output_size) {
            char value_char_sounds[2];
            for (int j = 0; j < sampleSize; j++) {
                value_char_sounds[j] = arr_sounds.at(i + j);
            }
            quint32 lilvalue = ((value_char_sounds[1] << 8) | value_char_sounds[0]);
            value += lilvalue;
            numAdds++;
        }
//        if (i + sampleSize - 1 < mic_output_size) {
//            char value_char_mic[2];
//            for (int j = 0; j < sampleSize; j++) {
//                value_char_mic[j] = arr_mic.at(i + j);
//            }
//            quint32 lilvalue = ((value_char_mic[1] << 8) | value_char_mic[0]);
//            if (lilvalue != 0 && lilvalue < maxAmplitude - 2000) {
//                value += lilvalue;
//                numAdds++;
//            }
//        }
        if (i + sampleSize - 1 < arr_track.size()) {
            char value_char_track[2];
            for (int j = 0; j < sampleSize; j++) {
                value_char_track[j] = arr_track.at(i + j);
            }
            quint32 lilvalue = ((value_char_track[1] << 8) | value_char_track[0]);
            value += lilvalue;
            numAdds++;
        }

        if (value < maxAmplitude) {
            quint16 final_value = value;
            quint16 v1 = (quint16)(final_value & 0xFF);
            quint16 v2 = (quint16)(final_value >> 8);
            fputc(v1, filewrite);
            fputc(v2, filewrite);
        } else {
            value /= numAdds;
            quint16 final_value = value;
            quint16 v1 = (quint16)(final_value & 0xFF);
            quint16 v2 = (quint16)(final_value >> 8);
            fputc(v1, filewrite);
            fputc(v2, filewrite);
        }
    }

    fclose(filewrite);

    // replace readTrack with writeTrack
    readTrack->close();
    writeTrack->close();
    readTrack->remove();
    writeTrack->copy(readTrack->fileName());
    writeTrack->remove();
    readTrack->open(QIODevice::ReadOnly);

    mic_output->close();
    sounds_output->close();
    mic_output->remove();
    sounds_output->remove();

//    mic_output->open(QIODevice::ReadWrite|QFile::Truncate);

    audioOutput->start(readTrack);
//    audioInput_mic->start(mic_output);
    recorder->record();
}

// play track
void AudioManager::play()
{
    playing = true;
    if (audioOutput->state() == QAudio::SuspendedState) {
        audioOutput->resume();
//        audioInput_mic->resume();
        recorder->record();
    } else if(readTrack->exists()) {
        audioOutput->start(readTrack);
//        audioInput_mic->start(mic_output);
        recorder->record();
    }
}

// pause track
void AudioManager::pause()
{
    playing = false;
    audioOutput->suspend();
}

// add sound file to sounds vector
void AudioManager::addSound(QFile *file)
{
    sounds.push_back(file);
}

// play the sound at sounds[index] and sound is added to track if recording
void AudioManager::playSound(int index)
{
    sounds_output->open(QIODevice::ReadOnly);

    int mic_output_size = mic_output->size();
    int sounds_output_size = sounds_output->size();

    // play sound
    QSoundEffect *sound = new QSoundEffect();
    sound->setSource(QUrl::fromLocalFile(sounds[index]->fileName()));
    sound->setLoopCount(1);
    sound->setVolume(1.0f);
    sound->play();

    // if recording, remove wav header and write raw sound to buffer_sound at current index
    if (recordingSoundboard) {
        if (!mic_output->isOpen()) {
            recorder->setVolume(0.0f);
            recorder->record();
        }

        WaveFile waveFile;

        // creates wavefile with byte array
        std::string filePath = sounds[index]->fileName().toStdString().substr(2);

        FILE *file = fopen(filePath.data(), "rb");
        fread(waveFile.ChunkID, 4, 1, file);
        fread(reinterpret_cast<char*>(&waveFile.ChunkSize), 4, 1, file);
        fread(waveFile.Format, 4, 1, file);
        fread(waveFile.SubChunkID, 4, 1, file);
        fread(reinterpret_cast<char*>(&waveFile.SubChunkSize), 4, 1, file);
        fread(reinterpret_cast<char*>(&waveFile.AudioFormat), 2, 1, file);
        fread(reinterpret_cast<char*>(&waveFile.NumChannels), 2, 1, file);
        fread(reinterpret_cast<char*>(&waveFile.SampleRate), 4, 1, file);
        fread(reinterpret_cast<char*>(&waveFile.ByteRate), 4, 1, file);
        fread(reinterpret_cast<char*>(&waveFile.BlockAlign), 2, 1, file);
        fread(reinterpret_cast<char*>(&waveFile.BitsPerSample), 2, 1, file);
        fread(waveFile.SubChunk2ID, 4, 1, file);
        fread(reinterpret_cast<char*>(&waveFile.SubChunk2Size), 4, 1, file);
        QByteArray data("");
        for (quint32 i = 0; i < waveFile.SubChunk2Size; i++) {
            data.push_back((unsigned char)fgetc(file));
        }

        fclose(file);

        QByteArray arr_sounds("");

        if (sounds_output->exists()) {
            arr_sounds = sounds_output->readAll();
        }

        sounds_output->close();

        sounds_output->open(QIODevice::WriteOnly | QFile::Truncate);

        // copies arr_sounds into sounds_output and fills silence until mic_output_size
        filePath = sounds_output->fileName().toStdString().substr(0);

        FILE *filewrite = fopen(filePath.data(), "wb");

        for (int i = 0; i < mic_output_size; i++) {
            if (i >= sounds_output_size) {
                fputc(0xff, filewrite);
            } else {
                fputc((quint16)arr_sounds.at(i), filewrite);
            }
        }

        int sampleSize = format.sampleSize() / 8;

        // copies sound data into sounds_output
        for (int i = mic_output_size; i + sampleSize - 1 < mic_output_size + data.size() || i + sampleSize - 1 < sounds_output_size + data.size(); i += sampleSize) {
            if (i >= sounds_output_size) {
                char value_char[2];
                for (int j = 0; j < sampleSize; j++) {
                    if (i - mic_output_size +j < data.size())
                        value_char[j] = data.at(i - mic_output_size + j);
                }
                quint16 final_value = (value_char[1] << 8) | value_char[0];
                quint16 v1 = (quint16)(final_value & 0xFF);
                quint16 v2 = (quint16)(final_value >> 8);
                fputc(v1, filewrite);
                fputc(v2, filewrite);
            } else {
                char value_char_sounds[2];
                char value_char_data[2];

                for (int j = 0; j < sampleSize; j++) {
                    if (i + j < arr_sounds.size())
                        value_char_sounds[j] = arr_sounds.at(i + j);
                    if (i - mic_output_size +j < data.size())
                        value_char_data[j] = data.at(i - mic_output_size + j);
                }

                quint32 value_int = ((value_char_sounds[1] << 8) | value_char_sounds[0]);
                value_int += ((value_char_data[1] << 8) | value_char_data[0]);

                if (value_int < maxAmplitude) {
                    quint16 final_value = value_int;
                    quint16 v1 = (quint16)(final_value & 0xFF);
                    quint16 v2 = (quint16)(final_value >> 8);
                    fputc(v1, filewrite);
                    fputc(v2, filewrite);
                } else {
                    quint16 final_value = maxAmplitude;
                    quint16 v1 = (quint16)(final_value & 0xFF);
                    quint16 v2 = (quint16)(final_value >> 8);
                    fputc(v1, filewrite);
                    fputc(v2, filewrite);
                }
            }
        }
        fclose(filewrite);
    }
    sounds_output->close();
}

// undo
void AudioManager::undo() {
    recorder->stop();
    mic_output->remove();
    sounds_output->remove();
    recorder->record();
}

// clear
void AudioManager::clear() {
    recorder->stop();
    mic_output->remove();
    sounds_output->remove();
    readTrack->remove();
    recorder->record();
}

// manages Audio Output State changes
void AudioManager::audioOutputStateChanged(QAudio::State state)
{
    if (state == QAudio::ActiveState) {
//        audioInput_mic->start(mic_output);
        recorder->record();
    } else if (state == QAudio::SuspendedState) {
//        audioInput_mic->suspend();
        recorder->stop();
    } else if (state == QAudio::IdleState) {
        audioOutput->stop();
        readTrack->close();
        readTrack->open(QIODevice::ReadOnly);
        audioOutput->start(readTrack);
    }
}
