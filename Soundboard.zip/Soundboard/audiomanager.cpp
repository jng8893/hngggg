#include "audiomanager.h"
#include <QUrl>
#include <QSoundEffect>
#include <fstream>
#include <sstream>

// the following struct is adapted from https://stackoverflow.com/questions/17968561/loading-and-saving-wav-file
struct WaveFile
{
public:

    static const quint16 NUM_CHARS = 4;

public:

    WaveFile() : Data(nullptr) {}

    ~WaveFile() { delete Data; }

    char ChunkID[NUM_CHARS] = {'R', 'I', 'F', 'F'};

    char ChunkSize[sizeof(quint32)];

    char Format[NUM_CHARS] = {'W', 'A', 'V', 'E'};

    char SubChunkID[NUM_CHARS] = {'f', 'm', 't'};

    char SubChunkSize[sizeof(quint32)] = {'0', '0', '1', '0'};

    char AudioFormat[sizeof(quint16)] = {'0', '1'};

    char NumChannels[sizeof(quint16)] = {'0', '2'};

    char SampleRate[sizeof(quint32)] = {'a', 'c', '4', '4'};

    char ByteRate[sizeof(quint32)];

    char BlockAlign[sizeof(quint16)];

    char BitsPerSample[sizeof(quint16)] = {'1', '0'};

    char SubChunk2ID[NUM_CHARS] = {'d', 'a', 't', 'a'};

    char SubChunk2Size[sizeof(quint32)];

    char* Data;
};

AudioManager::AudioManager()
{
    // sets up Audio Format
    format.setSampleRate(44100);
    format.setChannelCount(2);
    format.setSampleSize(16);
    format.setCodec("audio/pcm");
    format.setByteOrder(QAudioFormat::LittleEndian);
    format.setSampleType(QAudioFormat::SignedInt);

    // sets up readTrack
    readTrack = new QFile("readTrack.wav");
    readTrack->open(QIODevice::ReadOnly);

    // sets up buffers
    buffer_sounds = new QBuffer();
    buffer_mic = new QBuffer();
    buffer_track = new QBuffer();
    buffer_final = new QBuffer();

    // opens buffers
    buffer_sounds->open(QIODevice::WriteOnly);
    buffer_mic->open(QIODevice::WriteOnly);
    buffer_track->open(QIODevice::WriteOnly);
    buffer_track->open(QIODevice::WriteOnly);

    // sets up audioInput
    audioInput_mic = new QAudioInput(QAudioDeviceInfo::defaultInputDevice(), format);
    audioInput_mic->setVolume(0.0f);

    // sets up writeTrack
    writeTrack = new QFile("writeTrack.wav");

    // sets up audioOutput
    audioOutput = new QAudioOutput(QAudioDeviceInfo::defaultOutputDevice(), format);
    connect(audioOutput, SIGNAL(stateChanged(QAudio::State)),
            this, SLOT (audioOutputStateChanged(QAudio::State)));
}

AudioManager::~AudioManager()
{
    readTrack->close();
    writeTrack->close();
    readTrack->remove();
    writeTrack->remove();
}

void AudioManager::setAudioFormat(QAudioFormat &format) {
    this->format = format;

    // the following was adapted from qt example audioinput
    switch (format.sampleSize()) {
    case 8:
        switch (format.sampleType()) {
        case QAudioFormat::UnSignedInt:
            maxAmplitude = 255;
            break;
        case QAudioFormat::SignedInt:
            maxAmplitude = 127;
            break;
        default:
            break;
        }
        break;
    case 16:
        switch (format.sampleType()) {
        case QAudioFormat::UnSignedInt:
            maxAmplitude = 65535;
            break;
        case QAudioFormat::SignedInt:
            maxAmplitude = 32767;
            break;
        default:
            break;
        }
        break;

    case 32:
        switch (format.sampleType()) {
        case QAudioFormat::UnSignedInt:
            maxAmplitude = 0xffffffff;
            break;
        case QAudioFormat::SignedInt:
            maxAmplitude = 0x7fffffff;
            break;
        case QAudioFormat::Float:
            maxAmplitude = 0x7fffffff;
        default:
            break;
        }
        break;

    default:
        break;
    }
}

bool AudioManager::isPlaying()
{
    return playing;
}

void AudioManager::setRecordingSoundboard(bool recording)
{
    this->recordingSoundboard = recording;
}

bool AudioManager::isRecordingSoundboard()
{
    return recordingSoundboard;
}

void AudioManager::setRecordingMic(bool recording)
{
    this->recordingMic = recording;

    // mute audioInput if not recording
    if (recording) {
        audioInput_mic->setVolume(1.0f);
        if (!readTrack->exists()) {
            audioInput_mic->start(buffer_mic);
        }
    } else {
        audioInput_mic->setVolume(0.0f);
    }
}

bool AudioManager::isRecordingMic()
{
    return recordingMic;
}

QFile* AudioManager::getTrack()
{
    return readTrack;
}

// loop track
void AudioManager::loop()
{
    int buffer_mic_size = buffer_mic->data().size();
    int buffer_sounds_size = buffer_sounds->data().size();

    // fills buffer_track to current index with readTrack

    WaveFile waveFile;

    std::string string;
    std::stringstream sstream;

    QByteArray *arr = new QByteArray("");
    if (readTrack->exists()) {
        readTrack->close();
        // creates wavefile with byte array
        // the following is adapted from https://stackoverflow.com/questions/17968561/loading-and-saving-wav-file
        std::ifstream file(readTrack->fileName().toStdString(), std::ios::binary);
        file.read(waveFile.ChunkID, WaveFile::NUM_CHARS);
        file.read(waveFile.ChunkSize, sizeof(quint32));
        file.read(waveFile.Format, WaveFile::NUM_CHARS);
        file.read(waveFile.SubChunkID, WaveFile::NUM_CHARS);
        file.read(waveFile.SubChunkSize, sizeof(quint32));
        file.read(waveFile.AudioFormat, sizeof(quint16));
        file.read(waveFile.NumChannels, sizeof(quint16));
        file.read(waveFile.SampleRate, sizeof(quint32));
        file.read(waveFile.ByteRate, sizeof(quint32));
        file.read(waveFile.BlockAlign, sizeof(quint16));
        file.read(waveFile.BitsPerSample, sizeof(quint16));
        file.read(waveFile.SubChunk2ID, WaveFile::NUM_CHARS);
        file.read(waveFile.SubChunk2Size, sizeof(quint32));
        int subChunk2Size;
        string = waveFile.SubChunk2Size;
        sstream << std::hex << string;
        sstream >> subChunk2Size;
        waveFile.Data = new char[subChunk2Size];
        for (int i = 0; i < subChunk2Size; i++) {
            file.read(&waveFile.Data[i], 1);
        }
        file.close();

        QByteArray *data = new QByteArray(waveFile.Data);

        // puts track in at least once
        for (int i = 0; i < data->size(); i++) {
            arr->push_back(data->at(i));
        }

        // loops track until current index
        int i_waveFile = 0;
        for (int i = data->size(); i < buffer_mic_size || i < buffer_sounds_size; i++) {
            arr->push_back(data->at(i_waveFile));
            i_waveFile++;
            if (i_waveFile >= data->size()) {
                i_waveFile = 0;
            }
        }
    }

    // combines all buffers to single byte array
    QByteArray *arr_final = new QByteArray("");
    for (int i = 0; i < buffer_sounds_size || i < buffer_mic_size || i < arr->size();  i++) {
        char value;
        if (i < buffer_sounds->data().size()) {
            value += buffer_sounds->data().at(i);
        }
        if (i < buffer_mic->data().size()) {
            value += buffer_mic->data().at(i);
        }
        if (i < arr->size()) {
            value += arr->at(i);
        }
        if (value > maxAmplitude) {
            value = maxAmplitude;
        }
        arr_final->push_back(value);
    }

    qInfo() << arr_final->size();

    // writes final byte array to writeTrack

    writeTrack->open(QIODevice::WriteOnly);

    sstream << std::hex << arr_final->size();
    string = sstream.str();
    for (quint32 i = 0; i < sizeof(quint32); i++) {
        waveFile.SubChunk2Size[i] = string[i];
    }

    sstream << std::hex << format.sampleRate();
    string = sstream.str();
    for (quint32 i = 0; i < sizeof(quint32); i++) {
        waveFile.SampleRate[i] = string[i];
    }

    qInfo() << QString::fromUtf8(waveFile.ChunkID);
    qInfo() << QString::fromUtf8(waveFile.ChunkSize);
    qInfo() << QString::fromUtf8(waveFile.Format);
    qInfo() << QString::fromUtf8(waveFile.NumChannels);

    sstream << std::hex << format.channelCount();
    string = sstream.str();
    for (quint16 i = 0; i < sizeof(quint16); i++) {
        waveFile.NumChannels[i] = string[i];
    }

    int numChannels;
    string = std::string(waveFile.NumChannels);
    sstream << std::hex << string;
    sstream >> numChannels;

    qInfo() << QString::fromUtf8(waveFile.NumChannels);
    qInfo() << QString::fromStdString(string);
    qInfo() << QString::fromStdString(sstream.str());

    int bitsPerSample;
    string = std::string(waveFile.BitsPerSample);
    sstream << std::hex << string;
    sstream >> bitsPerSample;

    sstream << std::hex << (numChannels * bitsPerSample);
    string = sstream.str();
    for (quint16 i = 0; i < sizeof(quint16); i++) {
        waveFile.BlockAlign[i] = string[i];
    }

    int sampleRate;
    string = std::string(waveFile.SampleRate);
    sstream << std::hex << string;
    sstream >> sampleRate;

    sstream << std::hex << (sampleRate * numChannels * bitsPerSample/8);
    string = sstream.str();
    for (quint32 i = 0; i < sizeof(quint32); i++) {
        waveFile.ByteRate[i] = string[i];
    }

    sstream << std::hex << (36 + arr_final->size());
    string = sstream.str();
    for (quint32 i = 0; i < sizeof(quint32); i++) {
        waveFile.ChunkSize[i] = string[i];
    }

    // the following is adapted from https://stackoverflow.com/questions/17968561/loading-and-saving-wav-file
    std::ofstream filewrite(writeTrack->fileName().toStdString(), std::ios::binary);

    filewrite.flush();
    filewrite.write(waveFile.ChunkID, WaveFile::NUM_CHARS);
    filewrite.write(waveFile.ChunkSize, sizeof(sizeof(quint32)));
    filewrite.write(waveFile.Format, WaveFile::NUM_CHARS);
    filewrite.write(waveFile.SubChunkID, WaveFile::NUM_CHARS);
    filewrite.write(waveFile.SubChunkSize, sizeof(quint32));
    filewrite.write(waveFile.AudioFormat, sizeof(quint16));
    filewrite.write(waveFile.NumChannels, sizeof(quint16));
    filewrite.write(waveFile.SampleRate, sizeof(quint32));
    filewrite.write(waveFile.ByteRate, sizeof(quint32));
    filewrite.write(waveFile.BlockAlign, sizeof(quint16));
    filewrite.write(waveFile.BitsPerSample, sizeof(quint16));
    filewrite.write(waveFile.SubChunk2ID, WaveFile::NUM_CHARS);
    filewrite.write(waveFile.SubChunk2Size, sizeof(quint32));
    for (int i = 0; i < arr_final->size(); i++) {
        filewrite.write(&arr_final->data()[i], 1);
    }
    filewrite.close();

    // replace readTrack with writeTrack
    readTrack->close();
    writeTrack->close();
    readTrack->remove();
    writeTrack->copy(readTrack->fileName());
    writeTrack->remove();
    readTrack->open(QIODevice::ReadOnly);

    audioOutput->stop();
    audioOutput->start(readTrack);
}

// play track
void AudioManager::play()
{
    playing = true;
    if (audioOutput->state() == QAudio::SuspendedState) {
        audioOutput->resume();
        audioInput_mic->resume();
    } else if(readTrack->exists()) {
        audioOutput->start(readTrack);
        audioInput_mic->start(buffer_mic);
    }
}

// pause track
void AudioManager::pause()
{
    playing = false;
    audioOutput->suspend();
}

// add sound file to sounds vector
void AudioManager::addSound(QFile *file)
{
    sounds.push_back(file);
}

// play the sound at sounds[index] and sound is added to track if recording
void AudioManager::playSound(int index)
{
    int buffer_mic_size = buffer_mic->data().size();
    int buffer_sounds_size = buffer_sounds->data().size();

    // play sound
    QSoundEffect *sound = new QSoundEffect();
    sound->setSource(QUrl::fromLocalFile(sounds[index]->fileName()));
    sound->setLoopCount(1);
    sound->setVolume(1.0f);
    sound->play();

    std::stringstream sstream;

    // if recording, remove wav header and write raw sound to buffer_sound at current index
    if (recordingSoundboard) {
        WaveFile waveFile;

        // creates wavefile with byte array
        // the following is adapted from https://stackoverflow.com/questions/17968561/loading-and-saving-wav-file
        std::ifstream file(sounds[index]->fileName().toStdString(), std::ios::binary);
        file.read(waveFile.ChunkID, WaveFile::NUM_CHARS);
        file.read(waveFile.ChunkSize, sizeof(quint32));
        file.read(waveFile.Format, WaveFile::NUM_CHARS);
        file.read(waveFile.SubChunkID, WaveFile::NUM_CHARS);
        file.read(waveFile.SubChunkSize, sizeof(quint32));
        file.read(waveFile.AudioFormat, sizeof(quint16));
        file.read(waveFile.NumChannels, sizeof(quint16));
        file.read(waveFile.SampleRate, sizeof(quint32));
        file.read(waveFile.ByteRate, sizeof(quint32));
        file.read(waveFile.BlockAlign, sizeof(quint16));
        file.read(waveFile.BitsPerSample, sizeof(quint16));
        file.read(waveFile.SubChunk2ID, WaveFile::NUM_CHARS);
        file.read(waveFile.SubChunk2Size, sizeof(quint32));
        int subChunk2Size;
        std::string string = std::string(waveFile.SubChunk2Size);
        sstream << std::hex << string;
        sstream >> subChunk2Size;
        waveFile.Data = new char[subChunk2Size];
        for (int i = 0; i < subChunk2Size; i++) {
            file.read(&waveFile.Data[i], 1);
        }
        file.close();

        QByteArray *data = new QByteArray(waveFile.Data);

        QByteArray *arr = new QByteArray("");

        // copies buffer_sounds into new byte array and fills zeroes until buffer_mic size (current index)
        if (buffer_sounds_size < buffer_mic_size) {
            for (int i = 0; i < buffer_sounds_size; i++) {
                arr->push_back(buffer_sounds->data().at(i));
            }
            for (int i = buffer_sounds_size; i < buffer_mic_size; i++) {
                arr->push_back((char)0);
            }
        }

        // copies sound data into new byte array at current index
        for (int i = buffer_mic_size; i < buffer_mic_size + data->size(); i++) {
            if (i >= buffer_sounds->size()) {
                arr->push_back(data->at(i - buffer_mic_size));
            } else {
                char value = buffer_sounds->data().at(i) + data->at(i - buffer_mic_size);
                if (value < maxAmplitude) {
                    arr->push_back(value);
                } else {
                    arr->push_back(value);
                }
            }
        }

        buffer_sounds->setData(*arr);

        if (!readTrack->exists()) {
            audioInput_mic->start(buffer_mic);
        }
    }
}

// manages Audio Output State changes
void AudioManager::audioOutputStateChanged(QAudio::State state)
{
    if (state == QAudio::ActiveState) {
        audioInput_mic->start(buffer_mic);
    } else if (state == QAudio::SuspendedState) {
        audioInput_mic->suspend();
    } else if (state == QAudio::IdleState) {
        audioOutput->stop();
        readTrack->close();
        readTrack->open(QIODevice::ReadOnly);
        audioOutput->start(readTrack);
    }
}
