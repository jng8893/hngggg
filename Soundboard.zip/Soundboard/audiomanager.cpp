#include "audiomanager.h"
#include <QUrl>
#include <QSoundEffect>
#include <fstream>
#include <sstream>
#include <QtEndian>
#include <iostream>

// the following struct is adapted from https://stackoverflow.com/questions/17968561/loading-and-saving-wav-file
struct WaveFile
{
public:

    static const quint16 NUM_CHARS = 4;

public:

    WaveFile() : Data(nullptr) {}
    ~WaveFile() { delete Data; }

    char ChunkID[NUM_CHARS];
    quint32 ChunkSize;

    char Format[NUM_CHARS];

    char SubChunkID[NUM_CHARS];
    quint32 SubChunkSize;

    quint16 AudioFormat;
    quint16 NumChannels;
    quint32 SampleRate;
    quint32 ByteRate;
    quint16 BlockAlign;
    quint16 BitsPerSample;

    char SubChunk2ID[NUM_CHARS];
    quint32 SubChunk2Size;

    char* Data;
};

AudioManager::AudioManager()
{
    // sets up Audio Format
    format.setSampleRate(44100);
    format.setChannelCount(2);
    format.setSampleSize(16);
    format.setCodec("audio/pcm");
    format.setByteOrder(QAudioFormat::LittleEndian);
    format.setSampleType(QAudioFormat::SignedInt);

    // sets up readTrack
    readTrack = new QFile("readTrack.wav");
    readTrack->open(QIODevice::ReadOnly);

    // sets up buffers
    buffer_sounds = new QBuffer();
    buffer_mic = new QBuffer();
    buffer_track = new QBuffer();
    buffer_final = new QBuffer();

    // opens buffers
    buffer_sounds->open(QIODevice::ReadWrite);
    buffer_mic->open(QIODevice::ReadWrite);
    buffer_track->open(QIODevice::ReadWrite);
    buffer_track->open(QIODevice::ReadWrite);

    // sets up audioInput
    audioInput_mic = new QAudioInput(QAudioDeviceInfo::defaultInputDevice(), format);
    audioInput_mic->setVolume(0.0f);

    // sets up writeTrack
    writeTrack = new QFile("writeTrack.wav");

    // sets up audioOutput
    audioOutput = new QAudioOutput(QAudioDeviceInfo::defaultOutputDevice(), format);
    connect(audioOutput, SIGNAL(stateChanged(QAudio::State)),
            this, SLOT (audioOutputStateChanged(QAudio::State)));
}

AudioManager::~AudioManager()
{
    readTrack->close();
    writeTrack->close();
    readTrack->remove();
    writeTrack->remove();
}

void AudioManager::setAudioFormat(QAudioFormat &format) {
    this->format = format;

    // the following was adapted from qt example audioinput
    switch (format.sampleSize()) {
    case 8:
        switch (format.sampleType()) {
        case QAudioFormat::UnSignedInt:
            maxAmplitude = 255;
            break;
        case QAudioFormat::SignedInt:
            maxAmplitude = 127;
            break;
        default:
            break;
        }
        break;
    case 16:
        switch (format.sampleType()) {
        case QAudioFormat::UnSignedInt:
            maxAmplitude = 65535;
            break;
        case QAudioFormat::SignedInt:
            maxAmplitude = 32767;
            break;
        default:
            break;
        }
        break;

    case 32:
        switch (format.sampleType()) {
        case QAudioFormat::UnSignedInt:
            maxAmplitude = 0xffffffff;
            break;
        case QAudioFormat::SignedInt:
            maxAmplitude = 0x7fffffff;
            break;
        case QAudioFormat::Float:
            maxAmplitude = 0x7fffffff;
        default:
            break;
        }
        break;

    default:
        break;
    }
}

bool AudioManager::isPlaying()
{
    return playing;
}

void AudioManager::setRecordingSoundboard(bool recording)
{
    this->recordingSoundboard = recording;
}

bool AudioManager::isRecordingSoundboard()
{
    return recordingSoundboard;
}

void AudioManager::setRecordingMic(bool recording)
{
    this->recordingMic = recording;

    // mute audioInput if not recording
    if (recording) {
        audioInput_mic->setVolume(1.0f);
        if (!readTrack->exists()) {
            audioInput_mic->start(buffer_mic);
        }
    } else {
        audioInput_mic->setVolume(0.0f);
    }
}

bool AudioManager::isRecordingMic()
{
    return recordingMic;
}

QFile* AudioManager::getTrack()
{
    return readTrack;
}

// loop track
void AudioManager::loop()
{
    int buffer_mic_size = buffer_mic->data().size();
    int buffer_sounds_size = buffer_sounds->data().size();

    // fills buffer_track to current index with readTrack

    WaveFile waveFile;
    waveFile.ChunkID[0] = 'R';
    waveFile.ChunkID[1] = 'I';
    waveFile.ChunkID[2] = 'F';
    waveFile.ChunkID[3] = 'F';
    waveFile.Format[0] = 'W';
    waveFile.Format[1] = 'A';
    waveFile.Format[2] = 'V';
    waveFile.Format[3] = 'E';
    waveFile.SubChunkID[0] = 'f';
    waveFile.SubChunkID[1] = 'm';
    waveFile.SubChunkID[2] = 't';
    waveFile.SubChunkSize = 16;
    waveFile.AudioFormat = 1;
    waveFile.SubChunk2ID[0] = 'd';
    waveFile.SubChunk2ID[1] = 'a';
    waveFile.SubChunk2ID[2] = 't';
    waveFile.SubChunk2ID[3] = 'a';

    std::string string;
    std::stringstream sstream;
    std::string filePath;

    QByteArray *arr = new QByteArray("");
    if (readTrack->exists()) {
        readTrack->close();
        // creates wavefile with byte array
        // the following is adapted from https://stackoverflow.com/questions/17968561/loading-and-saving-wav-file
        std::ifstream file;
        filePath = readTrack->fileName().toStdString().substr(0);
        file.open(filePath, std::ios::binary);

        file.read(waveFile.ChunkID, WaveFile::NUM_CHARS);
        file.read(reinterpret_cast<char*>(&waveFile.ChunkSize), sizeof(quint32));
        file.read(waveFile.Format, WaveFile::NUM_CHARS);
        file.read(waveFile.SubChunkID, WaveFile::NUM_CHARS);
        file.read(reinterpret_cast<char*>(&waveFile.SubChunkSize), sizeof(quint32));
        file.read(reinterpret_cast<char*>(&waveFile.AudioFormat), sizeof(quint16));
        file.read(reinterpret_cast<char*>(&waveFile.NumChannels), sizeof(quint16));
        file.read(reinterpret_cast<char*>(&waveFile.SampleRate), sizeof(quint32));
        file.read(reinterpret_cast<char*>(&waveFile.ByteRate), sizeof(quint32));
        file.read(reinterpret_cast<char*>(&waveFile.BlockAlign), sizeof(quint16));
        file.read(reinterpret_cast<char*>(&waveFile.BitsPerSample), sizeof(quint16));
        file.read(waveFile.SubChunk2ID, WaveFile::NUM_CHARS);
        file.read(reinterpret_cast<char*>(&waveFile.SubChunk2Size), sizeof(quint32));
        waveFile.Data = new char[waveFile.SubChunk2Size];
        file.read(waveFile.Data, waveFile.SubChunk2Size);
        file.close();

        QByteArray *data = new QByteArray(waveFile.Data);

        // puts track in at least once
        for (int i = 0; i < data->size(); i++) {
            arr->push_back(data->at(i));
        }

        // loops track until current index
        int i_waveFile = 0;
        for (int i = data->size(); i < buffer_mic_size || i < buffer_sounds_size; i++) {
            arr->push_back(data->at(i_waveFile));
            i_waveFile++;
            if (i_waveFile >= data->size()) {
                i_waveFile = 0;
            }
        }
    }

    // combines all buffers to single byte array
    Q_ASSERT(format.sampleSize() % 8 == 0);
    const int channelByteSize = format.sampleSize() / 8;

    // test stuff
    QByteArray *arr_final = new QByteArray(buffer_sounds_size, (char)0);

    for (int i = 0; i < buffer_sounds_size; i++) {
        arr_final->push_back(buffer_sounds->data()[i]);
    }
    // end test stuff

//    for (int i = 0; i < buffer_sounds_size || i < buffer_mic_size || i < arr->size();  i+= channelByteSize) {
//        quint32 value = 0;
//        if (i < buffer_sounds->data().size()) {
//            if (format.sampleSize() == 8 && format.sampleType() == QAudioFormat::UnSignedInt) {
//                value += *reinterpret_cast<const quint8*>(buffer_sounds->data().data() + i);
//            } else if (format.sampleSize() == 8 && format.sampleType() == QAudioFormat::SignedInt) {
//                value += qAbs(*reinterpret_cast<const qint8*>(buffer_sounds->data().data() + i));
//            } else if (format.sampleSize() == 16 && format.sampleType() == QAudioFormat::UnSignedInt) {
//                if (format.byteOrder() == QAudioFormat::LittleEndian)
//                    value += qFromLittleEndian<quint16>(buffer_sounds->data().data() + i);
//                else
//                    value += qFromBigEndian<quint16>(buffer_sounds->data().data() + i);
//            } else if (format.sampleSize() == 16 && format.sampleType() == QAudioFormat::SignedInt) {
//                if (format.byteOrder() == QAudioFormat::LittleEndian)
//                    value += qAbs(qFromLittleEndian<qint16>(buffer_sounds->data().data() + i));
//                else
//                    value += qAbs(qFromBigEndian<quint16>(buffer_sounds->data().data() + i));
//            } else if (format.sampleSize() == 32 && format.sampleType() == QAudioFormat::UnSignedInt) {
//                if (format.byteOrder() == QAudioFormat::LittleEndian)
//                    value += qFromLittleEndian<quint32>(buffer_sounds->data().data() + i);
//                else
//                    value += qFromBigEndian<quint32>(buffer_sounds->data().data() + i);
//            } else if (format.sampleSize() == 32 && format.sampleType() == QAudioFormat::SignedInt) {
//                if (format.byteOrder() == QAudioFormat::LittleEndian)
//                    value += qAbs(qFromLittleEndian<qint32>(buffer_sounds->data().data() + i));
//                else
//                    value += qAbs(qFromBigEndian<qint32>(buffer_sounds->data().data() + i));
//            } else if (format.sampleSize() == 32 && format.sampleType() == QAudioFormat::Float) {
//                value += qAbs(*reinterpret_cast<const float*>(buffer_sounds->data().data() + i) * 0x7fffffff);
//            }
//        }
//        if (i < buffer_mic->data().size()) {
//            if (format.sampleSize() == 8 && format.sampleType() == QAudioFormat::UnSignedInt) {
//                value += *reinterpret_cast<const quint8*>(buffer_mic->data().data() + i);
//            } else if (format.sampleSize() == 8 && format.sampleType() == QAudioFormat::SignedInt) {
//                value += qAbs(*reinterpret_cast<const qint8*>(buffer_mic->data().data() + i));
//            } else if (format.sampleSize() == 16 && format.sampleType() == QAudioFormat::UnSignedInt) {
//                if (format.byteOrder() == QAudioFormat::LittleEndian)
//                    value += qFromLittleEndian<quint16>(buffer_mic->data().data() + i);
//                else
//                    value += qFromBigEndian<quint16>(buffer_mic->data().data() + i);
//            } else if (format.sampleSize() == 16 && format.sampleType() == QAudioFormat::SignedInt) {
//                if (format.byteOrder() == QAudioFormat::LittleEndian)
//                    value += qAbs(qFromLittleEndian<qint16>(buffer_mic->data().data() + i));
//                else
//                    value += qAbs(qFromBigEndian<quint16>(buffer_mic->data().data() + i));
//            } else if (format.sampleSize() == 32 && format.sampleType() == QAudioFormat::UnSignedInt) {
//                if (format.byteOrder() == QAudioFormat::LittleEndian)
//                    value += qFromLittleEndian<quint32>(buffer_mic->data().data() + i);
//                else
//                    value += qFromBigEndian<quint32>(buffer_mic->data().data() + i);
//            } else if (format.sampleSize() == 32 && format.sampleType() == QAudioFormat::SignedInt) {
//                if (format.byteOrder() == QAudioFormat::LittleEndian)
//                    value += qAbs(qFromLittleEndian<qint32>(buffer_mic->data().data() + i));
//                else
//                    value += qAbs(qFromBigEndian<qint32>(buffer_mic->data().data() + i));
//            } else if (format.sampleSize() == 32 && format.sampleType() == QAudioFormat::Float) {
//                value += qAbs(*reinterpret_cast<const float*>(buffer_mic->data().data() + i) * 0x7fffffff);
//            }
//        }
//        if (i < arr->size()) {
//            if (format.sampleSize() == 8 && format.sampleType() == QAudioFormat::UnSignedInt) {
//                value += *reinterpret_cast<const quint8*>(arr + i);
//            } else if (format.sampleSize() == 8 && format.sampleType() == QAudioFormat::SignedInt) {
//                value += qAbs(*reinterpret_cast<const qint8*>(arr + i));
//            } else if (format.sampleSize() == 16 && format.sampleType() == QAudioFormat::UnSignedInt) {
//                if (format.byteOrder() == QAudioFormat::LittleEndian)
//                    value += qFromLittleEndian<quint16>(arr + i);
//                else
//                    value += qFromBigEndian<quint16>(arr + i);
//            } else if (format.sampleSize() == 16 && format.sampleType() == QAudioFormat::SignedInt) {
//                if (format.byteOrder() == QAudioFormat::LittleEndian)
//                    value += qAbs(qFromLittleEndian<qint16>(arr + i));
//                else
//                    value += qAbs(qFromBigEndian<quint16>(arr + i));
//            } else if (format.sampleSize() == 32 && format.sampleType() == QAudioFormat::UnSignedInt) {
//                if (format.byteOrder() == QAudioFormat::LittleEndian)
//                    value += qFromLittleEndian<quint32>(arr + i);
//                else
//                    value += qFromBigEndian<quint32>(arr + i);
//            } else if (format.sampleSize() == 32 && format.sampleType() == QAudioFormat::SignedInt) {
//                if (format.byteOrder() == QAudioFormat::LittleEndian)
//                    value += qAbs(qFromLittleEndian<qint32>(arr + i));
//                else
//                    value += qAbs(qFromBigEndian<qint32>(arr + i));
//            } else if (format.sampleSize() == 32 && format.sampleType() == QAudioFormat::Float) {
//                value += qAbs(*reinterpret_cast<const float*>(arr + i) * 0x7fffffff);
//            }
//        }

//        if (value < maxAmplitude) {
//            char *val = reinterpret_cast<char*>(value);
//            for (quint32 i = 0; i < sizeof(value); i++) {
//                arr_final->push_back(val[i]);
//            }
//        } else {
//            char *val = reinterpret_cast<char*>(maxAmplitude);
//            for (quint32 i = 0; i < sizeof(value); i++) {
//                arr_final->push_back(val[i]);
//            }
//        }
//    }

    // writes final byte array to writeTrack

    writeTrack->open(QIODevice::WriteOnly);

    // change wavefile informatoin to format
    waveFile.NumChannels = format.channelCount();
    waveFile.SampleRate = format.sampleRate();
    waveFile.ByteRate = waveFile.SampleRate * waveFile.NumChannels * waveFile.BitsPerSample/8;
    waveFile.BlockAlign = waveFile.NumChannels * waveFile.BitsPerSample/8;
    waveFile.SubChunk2Size = arr_final->size();
    waveFile.ChunkSize = 36 + waveFile.SubChunk2Size;

    // the following is adapted from https://stackoverflow.com/questions/17968561/loading-and-saving-wav-file
    std::ofstream filewrite;
    filePath = writeTrack->fileName().toStdString().substr(0);
    filewrite.open(filePath, std::ios::binary);

    filewrite.flush();
    filewrite.write(waveFile.ChunkID, WaveFile::NUM_CHARS);
    filewrite.write(reinterpret_cast<const char*>(&waveFile.ChunkSize), sizeof(quint32));
    filewrite.write(waveFile.Format, WaveFile::NUM_CHARS);
    filewrite.write(waveFile.SubChunkID, WaveFile::NUM_CHARS);
    filewrite.write(reinterpret_cast<const char*>(&waveFile.SubChunkSize), sizeof(quint32));
    filewrite.write(reinterpret_cast<const char*>(&waveFile.AudioFormat), sizeof(quint16));
    filewrite.write(reinterpret_cast<const char*>(&waveFile.NumChannels), sizeof(quint16));
    filewrite.write(reinterpret_cast<const char*>(&waveFile.SampleRate), sizeof(quint32));
    filewrite.write(reinterpret_cast<const char*>(&waveFile.ByteRate), sizeof(quint32));
    filewrite.write(reinterpret_cast<const char*>(&waveFile.BlockAlign), sizeof(quint16));
    filewrite.write(reinterpret_cast<const char*>(&waveFile.BitsPerSample), sizeof(quint16));
    filewrite.write(waveFile.SubChunk2ID, WaveFile::NUM_CHARS);
    filewrite.write(reinterpret_cast<const char*>(&waveFile.SubChunk2Size), sizeof(quint32));
    filewrite.write(arr_final->data(), waveFile.SubChunk2Size);
    filewrite.close();

    // replace readTrack with writeTrack
    readTrack->close();
    writeTrack->close();
    readTrack->remove();
    writeTrack->copy(readTrack->fileName());
    writeTrack->remove();
    readTrack->open(QIODevice::ReadOnly);

    audioOutput->stop();
    audioOutput->start(readTrack);
}

// play track
void AudioManager::play()
{
    playing = true;
    if (audioOutput->state() == QAudio::SuspendedState) {
        audioOutput->resume();
        audioInput_mic->resume();
    } else if(readTrack->exists()) {
        audioOutput->start(readTrack);
        audioInput_mic->start(buffer_mic);
    }
}

// pause track
void AudioManager::pause()
{
    playing = false;
    audioOutput->suspend();
}

// add sound file to sounds vector
void AudioManager::addSound(QFile *file)
{
    sounds.push_back(file);
}

// play the sound at sounds[index] and sound is added to track if recording
void AudioManager::playSound(int index)
{
    int buffer_mic_size = buffer_mic->data().size();
    int buffer_sounds_size = buffer_sounds->data().size();

    if (!readTrack->exists()) {
        buffer_mic->open(QIODevice::ReadWrite);
        audioInput_mic->start(buffer_mic);
    }

    qInfo() << buffer_mic_size;
    qInfo() << buffer_sounds_size;

    // play sound
    QSoundEffect *sound = new QSoundEffect();
    sound->setSource(QUrl::fromLocalFile(sounds[index]->fileName()));
    sound->setLoopCount(1);
    sound->setVolume(1.0f);
    sound->play();

    std::stringstream sstream;

    // if recording, remove wav header and write raw sound to buffer_sound at current index
    if (recordingSoundboard) {
        WaveFile waveFile;

        // creates wavefile with byte array
        // the following is adapted from https://stackoverflow.com/questions/17968561/loading-and-saving-wav-file
        std::ifstream file;
        std::string filePath = sounds[index]->fileName().toStdString().substr(2);
        file.open(filePath, std::ios::binary);

        file.read(waveFile.ChunkID, WaveFile::NUM_CHARS);
        file.read(reinterpret_cast<char*>(&waveFile.ChunkSize), sizeof(quint32));
        file.read(waveFile.Format, WaveFile::NUM_CHARS);
        file.read(waveFile.SubChunkID, WaveFile::NUM_CHARS);
        file.read(reinterpret_cast<char*>(&waveFile.SubChunkSize), sizeof(quint32));
        file.read(reinterpret_cast<char*>(&waveFile.AudioFormat), sizeof(quint16));
        file.read(reinterpret_cast<char*>(&waveFile.NumChannels), sizeof(quint16));
        file.read(reinterpret_cast<char*>(&waveFile.SampleRate), sizeof(quint32));
        file.read(reinterpret_cast<char*>(&waveFile.ByteRate), sizeof(quint32));
        file.read(reinterpret_cast<char*>(&waveFile.BlockAlign), sizeof(quint16));
        file.read(reinterpret_cast<char*>(&waveFile.BitsPerSample), sizeof(quint16));
        file.read(waveFile.SubChunk2ID, WaveFile::NUM_CHARS);
        file.read(reinterpret_cast<char*>(&waveFile.SubChunk2Size), sizeof(quint32));
        waveFile.Data = new char[waveFile.SubChunk2Size];
        file.read(waveFile.Data, waveFile.SubChunk2Size);
        file.close();

        QByteArray *data = new QByteArray(waveFile.Data);

        QByteArray *arr = new QByteArray();

        // copies buffer_sounds into new byte array and fills zeroes until buffer_mic size (current index)
        for (int i = 0; i < buffer_mic_size; i++) {
            if (i >= buffer_sounds_size) {
                arr->push_back((char)0);
            } else {
                arr->push_back(buffer_sounds->data().at(i));
            }
        }

        Q_ASSERT(format.sampleSize() % 8 == 0);
        const int channelByteSize = format.sampleSize() / 8;

        // copies sound data into new byte array at current index
        for (int i = buffer_mic_size; i < buffer_mic_size + data->size(); i += channelByteSize) {
            if (i >= buffer_sounds_size) {
                for (int j = 0; j < channelByteSize; j++) {
                    arr->push_back(data->at(i - buffer_mic_size + j));
                }
            } else {
                quint32 value = 0;

                if (format.sampleSize() == 8 && format.sampleType() == QAudioFormat::UnSignedInt) {
                    value = *reinterpret_cast<const quint8*>(buffer_sounds->data().data() + i) + *reinterpret_cast<const quint8*>(data->data() - buffer_mic_size + i);
                } else if (format.sampleSize() == 8 && format.sampleType() == QAudioFormat::SignedInt) {
                    value = qAbs(*reinterpret_cast<const qint8*>(buffer_sounds->data().data() + i) + *reinterpret_cast<const qint8*>(data->data() - buffer_mic_size + i));
                } else if (format.sampleSize() == 16 && format.sampleType() == QAudioFormat::UnSignedInt) {
                    if (format.byteOrder() == QAudioFormat::LittleEndian)
                        value = qFromLittleEndian<quint16>(buffer_sounds->data().data() + i) + qFromLittleEndian<quint16>(data->data() - buffer_mic_size + i);
                    else
                        value = qFromBigEndian<quint16>(buffer_sounds->data().data() + i) + qFromBigEndian<quint32>(data->data() - buffer_mic_size + i);
                } else if (format.sampleSize() == 16 && format.sampleType() == QAudioFormat::SignedInt) {
                    if (format.byteOrder() == QAudioFormat::LittleEndian)
                        value = qAbs(qFromLittleEndian<qint16>(buffer_sounds->data().data() + i) + qFromLittleEndian<qint16>(data->data() - buffer_mic_size + i));
                    else
                        value = qAbs(qFromBigEndian<quint16>(buffer_sounds->data().data() + i) + qFromBigEndian<quint32>(data->data() - buffer_mic_size + i));
                } else if (format.sampleSize() == 32 && format.sampleType() == QAudioFormat::UnSignedInt) {
                    if (format.byteOrder() == QAudioFormat::LittleEndian)
                        value = qFromLittleEndian<quint32>(buffer_sounds->data().data() + i) + qFromLittleEndian<quint32>(data->data() - buffer_mic_size + i);
                    else
                        value = qFromBigEndian<quint32>(buffer_sounds->data().data() + i) + qFromBigEndian<quint32>(data->data() - buffer_mic_size + i);
                } else if (format.sampleSize() == 32 && format.sampleType() == QAudioFormat::SignedInt) {
                    if (format.byteOrder() == QAudioFormat::LittleEndian)
                        value = qAbs(qFromLittleEndian<qint32>(buffer_sounds->data().data() + i) + qFromLittleEndian<qint32>(data->data() - buffer_mic_size + i));
                    else
                        value = qAbs(qFromBigEndian<qint32>(buffer_sounds->data().data() + i) + qFromBigEndian<qint32>(data->data() - buffer_mic_size + i));
                } else if (format.sampleSize() == 32 && format.sampleType() == QAudioFormat::Float) {
                    value = qAbs(*reinterpret_cast<const float*>(buffer_sounds->data().data() + i) * 0x7fffffff + *reinterpret_cast<const float*>(data->data() - buffer_mic_size + i) * 0x7fffffff);
                }

                if (value < maxAmplitude) {
                    char *val = reinterpret_cast<char*>(value);
                    for (quint32 i = 0; i < sizeof(value); i++) {
                        arr->push_back(val[i]);
                    }
                } else {
                    char *val = reinterpret_cast<char*>(maxAmplitude);
                    for (quint32 i = 0; i < sizeof(value); i++) {
                        arr->push_back(val[i]);
                    }
                }
            }
        }

        buffer_sounds->close();
        buffer_sounds->setData(*arr);
        buffer_sounds->open(QIODevice::ReadWrite);
    }
}

// manages Audio Output State changes
void AudioManager::audioOutputStateChanged(QAudio::State state)
{
    if (state == QAudio::ActiveState) {
        audioInput_mic->start(buffer_mic);
    } else if (state == QAudio::SuspendedState) {
        audioInput_mic->suspend();
    } else if (state == QAudio::IdleState) {
        audioOutput->stop();
        readTrack->close();
        readTrack->open(QIODevice::ReadOnly);
        audioOutput->start(readTrack);
    }
}
