#ifndef AUDIOMANAGER_H
#define AUDIOMANAGER_H

#include <QFile>
#include <QAudioOutput>
#include <QAudioInput>
#include <QAudioRecorder>
#include <QBuffer>
#include <vector>
#include <fstream>
#include <iostream>

class AudioManager : public QObject
{
    Q_OBJECT

public:
    AudioManager();
    ~AudioManager();

    void setAudioFormat(QAudioFormat &format);

    bool isPlaying();
    void setRecordingSoundboard(bool recording);
    bool isRecordingSoundboard();
    void setRecordingMic(bool recording);
    bool isRecordingMic();

    QFile* getTrack();
    void play();
    void pause();
    void loop();

    void addSound(QFile *file);
    void playSound(int index);

private:
    QAudioFormat format;
    quint32 maxAmplitude;

    QAudioInput *audioInput_sounds;
    QAudioInput *audioInput_mic;
    QAudioInput *audioInput_track;
    QAudioInput *audioInput_final;

    QBuffer *buffer_sounds;
    QBuffer *buffer_mic;
    QBuffer *buffer_track;
    QBuffer *buffer_final;

    QAudioOutput *audioOutput;

    bool playing = false;
    bool recordingSoundboard = false;
    bool recordingMic = false;

    QFile *readTrack;
    QFile *writeTrack;

    std::vector<QFile*> sounds;

private slots:
    void audioOutputStateChanged(QAudio::State);
};

#endif // AUDIOMANAGER_H
